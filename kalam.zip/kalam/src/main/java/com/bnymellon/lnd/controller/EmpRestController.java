package com.bnymellon.lnd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.bnymellon.lnd.dao.EmpDaoImpl;
import com.bnymellon.lnd.model.Emp;

@RestController
public class EmpRestController {

                @Autowired
                private EmpDaoImpl empDaoImpl;

                @CrossOrigin
                @GetMapping("/employees")
                public List<Emp> getAllEmployees() {
                                return empDaoImpl.getAllEmployees();
                }
                
                @CrossOrigin
                @GetMapping("/employees/{id}")
                public ResponseEntity<Object> getEmployee(@PathVariable("id") String id) {
                                Emp emp = empDaoImpl.getEmployeeById(id);
                                if (emp == null) {
                                                return new ResponseEntity<Object>("No Employee found for ID " + id, HttpStatus.NOT_FOUND);
                                } 
                                return new ResponseEntity<Object>(emp, HttpStatus.OK);
                }

                
           
}









