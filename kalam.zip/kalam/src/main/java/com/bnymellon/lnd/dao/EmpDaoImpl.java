package com.bnymellon.lnd.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bnymellon.lnd.model.Emp;
import com.bnymellon.lnd.util.EmpRowMapper;

public class EmpDaoImpl {

	private JdbcTemplate template;

	public EmpDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	public Emp getEmployeeById(String searchById) {
		Emp foundEmployee = null;
		String query = "SELECT *  FROM XBBNHNG_LOGIN WHERE USERID like '%" + searchById+"%'";
		System.out.println(query);
		foundEmployee = template.queryForObject(query, new EmpRowMapper());
		return foundEmployee;
	}
	public List<Emp> getAllEmployees() {
		List<Emp> allEmployees = null;
		String query = "SELECT * FROM XBBNHNG_LOGIN";
		System.out.println(query);
		allEmployees = template.query(query, new EmpRowMapper());
		System.out.println(allEmployees.size());
		return allEmployees;
	}

}
