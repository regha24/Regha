package com.bnymellon.lnd.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bnymellon.lnd.model.Emp;

public class EmpRowMapper implements RowMapper<Emp> {

	@Override
	public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
		Emp tempEmp = new Emp();
		tempEmp.setUserId(rs.getString(1));
		tempEmp.setUserPassword(rs.getString(2));
		tempEmp.setUserRole(rs.getString(3));
		tempEmp.setUserName(rs.getString(4));
	
		return tempEmp;
	}

}
