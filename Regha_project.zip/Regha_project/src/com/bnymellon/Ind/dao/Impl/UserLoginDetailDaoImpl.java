package com.bnymellon.Ind.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bnymellon.lnd.dao.UserLoginDetailDao;
import com.bnymellon.lnd.model.UserLogin;
import com.bnymellon.lnd.util.ConnectionFactory;
import com.bnymellon.lnd.util.DbUtil;

public class UserLoginDetailDaoImpl implements UserLoginDetailDao {

	   private Connection connection = null;
       private PreparedStatement preparedstatement = null;
       private Statement statement; 
       String query = null;
	@Override
	public UserLogin getDetail(String userId, String userPassword)
			throws SQLException {

		query="select * from XBBNHNG_Login where userId= '"+userId+"' and userPassword= '"+userPassword+"' ";
        ResultSet rs=null;
        UserLogin emp=null;
        try{

                connection = ConnectionFactory.getConnection();
                if(connection==null)
                {System.out.println("connection is not");}
                statement = connection.createStatement();
                rs = statement.executeQuery(query);

                if (rs.next()) 

                {
                	emp=new UserLogin();
                	emp.setUserId(rs.getString(1));
                	emp.setUserPassword(rs.getString(2));
                	emp.setUserRole(rs.getString(3));
                	emp.setUserName(rs.getString(4));
                }
	}
        catch(SQLException e)
        {System.out.println(e.getMessage());}
        finally {
                DbUtil.close(rs);
                DbUtil.close(preparedstatement);
                DbUtil.close(connection);
        		}
        return emp;
	}
}
