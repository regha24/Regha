package com.bnymellon.Ind.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bnymellon.lnd.dao.BookDetailDao;
import com.bnymellon.lnd.model.BookDetails;

public class BookDetailDaoImpl implements BookDetailDao {

	private Connection connection = null;
	private PreparedStatement preparedstatement = null;
	String query=null;
	int rowsInserted=0;
	@Override
	public void addDetail(BookDetails check) throws SQLException 
	{
		
		 query = "insert into XBBNHNG_BookDetail values (?,?,?,?,?,?)";
		try {
			connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
			connection.setAutoCommit(false);
			preparedstatement = connection.prepareStatement(query);
			preparedstatement.setString(1, check.getBookId().toUpperCase());
			preparedstatement.setString(2, check.getBookName());
			preparedstatement.setString(3,check.getBookAuthor());
			preparedstatement.setInt(4,check.getBookQuantity());
			preparedstatement.setInt(5,check.getBookPages());
			preparedstatement.setInt(6,check.getBookIsbn());
			rowsInserted = preparedstatement.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A new account was saved successfully!");
				connection.commit();
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {

			com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
			com.bnymellon.lnd.util.DbUtil.close(connection);
		}
	
	}
	@Override
	public List<BookDetails> allBook() throws SQLException {
		
		
		query = "select * from XBBNHNG_BookDetail";
		ResultSet rs = null;
		List<BookDetails> checkList = new ArrayList<BookDetails>();
		BookDetails currentBook = null;
		try {
			connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
			preparedstatement = connection.prepareStatement(query);
			rs = preparedstatement.executeQuery();
			while (rs.next()) {
				currentBook = new BookDetails();
				currentBook.setBookAuthor(rs.getString(3));
				currentBook.setBookId(rs.getString(1));
				currentBook.setBookName(rs.getString(2));
				currentBook.setBookQuantity(rs.getInt(4));
				currentBook.setBookPages(rs.getInt(5));
				currentBook.setBookIsbn(rs.getInt(6));
				checkList.add(currentBook);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			com.bnymellon.lnd.util.DbUtil.close(rs);
			com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
			com.bnymellon.lnd.util.DbUtil.close(connection);
		}
		return checkList;
		
	}
	
	
	@Override
	public List<BookDetails> issuedBook(String userId, String bookId) throws SQLException {

		System.out.println(userId);
		query = "select d.bookAuthor,d.bookId,d.bookName,d.bookPages,d.bookIsbn from  XBBNHNG_BookIssued i,XBBNHNG_BookDetail d where i.bookId=d.bookId and i.userId='"+userId+"' ";
		ResultSet rs = null;
		List<BookDetails> checkList = new ArrayList<BookDetails>();
		BookDetails currentBook = null;
		try {
			connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
			preparedstatement = connection.prepareStatement(query);
			rs = preparedstatement.executeQuery(query);
			System.out.println(query);
			while(rs.next()) {
				System.out.println("sagarcheck");
				currentBook = new BookDetails();
				currentBook.setBookAuthor(rs.getString(1));
				currentBook.setBookId(rs.getString(2));
				currentBook.setBookName(rs.getString(3));
				currentBook.setBookPages(rs.getInt(4));
				currentBook.setBookIsbn(rs.getInt(5));
				checkList.add(currentBook);
				System.out.println("sagarEnd");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			com.bnymellon.lnd.util.DbUtil.close(rs);
			com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
			com.bnymellon.lnd.util.DbUtil.close(connection);
		}
		return checkList;
	}
	@Override
	public void updateBookDetails(String bookId, BookDetails complaint) throws SQLException {
		query = "update XBBNHNG_BookDetail set bookquantity=? where bookId='"+bookId+"'";
		try {
			connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
			preparedstatement = connection.prepareStatement(query);
			preparedstatement.setInt(1, complaint.getBookQuantity());
			preparedstatement.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			connection.commit();
			com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
			com.bnymellon.lnd.util.DbUtil.close(connection);
		}
	}
	@Override
	public BookDetails getDetail(String bookId) throws SQLException {

		ResultSet rs = null;

		BookDetails emp = null;
		query = "select * from XBBNHNG_BookDetail where bookId="+bookId;
		try {
			connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
			preparedstatement = connection.prepareStatement(query);
			rs = preparedstatement.executeQuery(query);
			if (rs.next()) {
				emp = new BookDetails();
				emp.setBookQuantity(rs.getInt("BOOKQUANTITY"));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {

			connection.commit();
			com.bnymellon.lnd.util.DbUtil.close(rs);
			com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
			com.bnymellon.lnd.util.DbUtil.close(connection);

		}
		return emp;

	}

}
