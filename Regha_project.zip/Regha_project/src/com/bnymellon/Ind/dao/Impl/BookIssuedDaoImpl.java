package com.bnymellon.Ind.dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bnymellon.lnd.dao.BookIssuedDao;
import com.bnymellon.lnd.model.BookDetails;
import com.bnymellon.lnd.model.BookIssued;
import com.bnymellon.lnd.model.UserBookDetails;

public class BookIssuedDaoImpl implements BookIssuedDao {


	private Connection connection = null;
	private PreparedStatement preparedstatement = null;
	String query=null;
	int rowsInserted=0;

	@Override
	public void addDetail(BookIssued check) throws SQLException {
		
		 query = "insert into XBBNHNG_BOOKISSUED values (?,?,?,?)";
			try {
				connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
				connection.setAutoCommit(false);
				preparedstatement = connection.prepareStatement(query);
				preparedstatement.setString(1, check.getBookId().toUpperCase());
				preparedstatement.setString(2, check.getBookName().toUpperCase());
				preparedstatement.setString(3,check.getUserId().toUpperCase());
				preparedstatement.setString(4,check.getUserName().toUpperCase());
				rowsInserted = preparedstatement.executeUpdate();
				if (rowsInserted > 0) {
					System.out.println("A new account was saved successfully!");
					connection.commit();
				}

			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {

				com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
				com.bnymellon.lnd.util.DbUtil.close(connection);
			}	
	}

	@Override
	public String getDetail(String bookId, String userId) throws SQLException {

		ResultSet rs = null;
		String check="NO";
		query = "select * from  XBBNHNG_BOOKISSUED where bookId="+bookId.toUpperCase()+" and userId='"+userId.toUpperCase()+"' ";
		try {
			connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
			preparedstatement = connection.prepareStatement(query);
			rs = preparedstatement.executeQuery();
			System.out.println(query);
			System.out.println(rs.getRow());
			if(rs.next()) {
				check="YES";
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {

			connection.commit();
			com.bnymellon.lnd.util.DbUtil.close(rs);
			com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
			com.bnymellon.lnd.util.DbUtil.close(connection);

		}
		return check;
	}

	@Override
	public void delete(String bookId) throws SQLException {
		query = "delete from XBBNHNG_BOOKISSUED where bookId=?";
		try {
			System.out.println("sagarDelete");
			connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
			connection.setAutoCommit(false);
			preparedstatement = connection.prepareStatement(query);
			preparedstatement.setString(1, bookId);
			preparedstatement.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
				connection.commit();
			com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
			com.bnymellon.lnd.util.DbUtil.close(connection);
		}
		
		
	}

	@Override
	public List<UserBookDetails> issuedBook() throws SQLException {
		
		query = "select d.bookAuthor,d.bookId,d.bookName,d.bookQuantity,d.bookPages,d.bookIsbn,i.userId,i.userName from  XBBNHNG_BookIssued i,XBBNHNG_BookDetail d where i.bookId=d.bookId";
		ResultSet rs = null;
		List<UserBookDetails> checkList = new ArrayList<UserBookDetails>();
		UserBookDetails currentBook = null;
		try {
			connection = com.bnymellon.lnd.util.ConnectionFactory.getConnection();
			preparedstatement = connection.prepareStatement(query);
			rs = preparedstatement.executeQuery();
			while (rs.next()) {
				currentBook = new UserBookDetails();
				currentBook.setBookAuthor(rs.getString(1));
				currentBook.setBookId(rs.getString(2));
				currentBook.setBookName(rs.getString(3));
				currentBook.setBookQuantity(rs.getInt(4));
				currentBook.setBookPages(rs.getInt(5));
				currentBook.setBookIsbn(rs.getInt(6));
				currentBook.setUserId(rs.getString(7));
				currentBook.setUserName(rs.getString(8));
				checkList.add(currentBook);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			com.bnymellon.lnd.util.DbUtil.close(rs);
			com.bnymellon.lnd.util.DbUtil.close(preparedstatement);
			com.bnymellon.lnd.util.DbUtil.close(connection);
		}
		return checkList;
	}
}
