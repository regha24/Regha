package com.bnymellon.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bnymellon.Ind.dao.Impl.BookDetailDaoImpl;
import com.bnymellon.lnd.dao.BookDetailDao;
import com.bnymellon.lnd.model.BookDetails;

/**
 * Servlet implementation class userIssue
 */
@WebServlet("/userIssue")
public class userIssue extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userIssue() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		BookDetailDao check=new BookDetailDaoImpl();
		List<BookDetails> allDetail=null;
		String bookId=(String) session.getAttribute("bookId");
		String userId=(String) session.getAttribute("userId");
		try {
			allDetail=check.issuedBook(userId, bookId);
			System.out.println(allDetail);
			request.setAttribute("allDetails", allDetail);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/userIssue.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
