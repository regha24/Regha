package com.bnymellon.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bnymellon.Ind.dao.Impl.BookDetailDaoImpl;
import com.bnymellon.Ind.dao.Impl.BookIssuedDaoImpl;
import com.bnymellon.lnd.dao.BookDetailDao;
import com.bnymellon.lnd.dao.BookIssuedDao;
import com.bnymellon.lnd.model.BookDetails;

/**
 * Servlet implementation class DoReturn
 */
@WebServlet("/DoReturn")
public class DoReturn extends HttpServlet {
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 4676222327338330388L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public DoReturn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		String bookId=(String) request.getParameter("id");
		System.out.println(bookId);
		
		BookDetailDao checkQuantity=new BookDetailDaoImpl();
		int quantity=0;
		try {
			BookDetails checkQuan=null;
			checkQuan=checkQuantity.getDetail(bookId);
			quantity=checkQuan.getBookQuantity();
			System.out.println(quantity);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		BookIssuedDao check=new BookIssuedDaoImpl();
		try {
			check.delete(bookId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		quantity=quantity+1;
		BookDetails check1=new BookDetails();
		check1.setBookQuantity(quantity);
		try {
			checkQuantity.updateBookDetails(bookId, check1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/userIssue");
	
	dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
