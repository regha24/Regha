package com.bnymellon.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bnymellon.Ind.dao.Impl.BookDetailDaoImpl;
import com.bnymellon.Ind.dao.Impl.BookIssuedDaoImpl;
import com.bnymellon.lnd.dao.BookDetailDao;
import com.bnymellon.lnd.dao.BookIssuedDao;
import com.bnymellon.lnd.model.BookDetails;
import com.bnymellon.lnd.model.BookIssued;

/**
 * Servlet implementation class DoIssue
 */
@WebServlet("/DoIssue")
public class DoIssue extends HttpServlet {
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 833453250649172466L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public DoIssue() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(true);
		
		String bookId=(String) request.getParameter("id");
		String bookName=(String) request.getParameter("name");
		String userName=(String) session.getAttribute("userName");
		String userId=(String) session.getAttribute("userId");
		BookDetailDao checkQuantity=new BookDetailDaoImpl();
		int quantity=0;
		String xy=null;
		String check=null;
		
		session.setAttribute("bookId", bookId);
		try {
			BookDetails checkQuan=null;
			checkQuan=checkQuantity.getDetail(bookId);
			quantity=checkQuan.getBookQuantity();
			System.out.println(quantity);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BookIssuedDao xyz=new BookIssuedDaoImpl();
		try {
			check=xyz.getDetail(bookId, userId);
			System.out.println(check);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(quantity<1)
		{
				xy="BOOK IS Not Present";
			request.setAttribute("errorMessage", xy);
			System.out.println(xy);
		}
		else
		{
			if(check.equals("YES"))
			{xy="BOOK IS PRESENT IN YOUR ACCOUNT";
			request.setAttribute("errorMessage", xy);
			System.out.println(xy);
			}
			else
			{
				BookIssued allDetail=new BookIssued();
				allDetail.setBookName(bookName);
				allDetail.setBookId(bookId);
				allDetail.setUserId(userName);
				allDetail.setUserName(userId);
				try {
					xyz.addDetail(allDetail);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				quantity=quantity-1;
				BookDetails check1=new BookDetails();
				check1.setBookQuantity(quantity);
				try {
					checkQuantity.updateBookDetails(bookId, check1);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

				RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/userView");
			
			dispatcher.forward(request, response);
				
			}
			
			
		}

		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/userView");
	
	dispatcher.forward(request, response);
			
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
