package com.bnymellon.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bnymellon.Ind.dao.Impl.BookDetailDaoImpl;
import com.bnymellon.lnd.dao.BookDetailDao;
import com.bnymellon.lnd.model.BookDetails;

/**
 * Servlet implementation class View
 */
@WebServlet("/View")
public class View extends HttpServlet {
	
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 4595783096326252929L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public View() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		BookDetailDao check=new BookDetailDaoImpl();
		List<BookDetails> allDetail=null;
		try {
			allDetail=check.allBook();
			System.out.println(allDetail);
			request.setAttribute("allDetails", allDetail);
			RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/View.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
