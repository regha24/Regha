package com.bnymellon.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bnymellon.Ind.dao.Impl.BookIssuedDaoImpl;
import com.bnymellon.lnd.dao.BookIssuedDao;
import com.bnymellon.lnd.model.UserBookDetails;

/**
 * Servlet implementation class Issue
 */
@WebServlet("/Issue")
public class Issue extends HttpServlet {
	
       
    /**
	 * 
	 */
	private static final long serialVersionUID = -585623054380695492L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public Issue() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<UserBookDetails> allDetail=null;
		BookIssuedDao check=new BookIssuedDaoImpl();
			try {
				allDetail= check.issuedBook();
				System.out.println(allDetail);
				request.setAttribute("allDetails", allDetail);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/Issue.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
