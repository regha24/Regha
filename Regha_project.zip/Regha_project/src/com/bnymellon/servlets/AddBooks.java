package com.bnymellon.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bnymellon.Ind.dao.Impl.BookDetailDaoImpl;
import com.bnymellon.lnd.dao.BookDetailDao;
import com.bnymellon.lnd.model.BookDetails;

/**
 * Servlet implementation class AddBooks
 */
@WebServlet("/AddBooks")
public class AddBooks extends HttpServlet {
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 8121366473429738222L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public AddBooks() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		BookDetails getDetails=new BookDetails();
		getDetails.setBookAuthor(request.getParameter("bookAuthor"));
		getDetails.setBookId(request.getParameter("bookID"));
		getDetails.setBookName(request.getParameter("bookName"));
		getDetails.setBookQuantity(Integer.parseInt(request.getParameter("bookQuantity")));
		getDetails.setBookPages(Integer.parseInt(request.getParameter("bookPages")));
		getDetails.setBookIsbn(Integer.parseInt(request.getParameter("bookIsbn")));
		BookDetailDao book=new BookDetailDaoImpl();
		try {
			book.addDetail(getDetails);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/home.jsp");
		
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
