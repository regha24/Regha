package com.bnymellon.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bnymellon.Ind.dao.Impl.UserLoginDetailDaoImpl;
import com.bnymellon.lnd.dao.UserLoginDetailDao;
import com.bnymellon.lnd.model.UserLogin;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	
       
    /**
	 * 
	 */

	/**
	 * 
	 */
	private static final long serialVersionUID = 1267491913826133964L;

	/**
     * @see HttpServlet#HttpServlet()
     */
    public Validate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		HttpSession session = request.getSession(true);
		String username=request.getParameter("name");
		String password=request.getParameter("password");
		UserLogin m=null;
		UserLoginDetailDao check=new UserLoginDetailDaoImpl();
		
		System.out.println(username);
		
		try{
			m=check.getDetail(username,password);
			session.setAttribute("userId", m.getUserId());
			session.setAttribute("userName",m.getUserName());
			
		if(m!=null && m.getUserRole().equals("admin"))
		{
			
			RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/home.jsp");
		
		dispatcher.forward(request, response);
		}
		else{
			
			request.setAttribute("errorstring", "Not Valid");
			RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/userHome.jsp");
		
		dispatcher.forward(request, response);}
	
			
			
		}
		catch(SQLException e)
		{RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/userHome.jsp");
		
		dispatcher.forward(request, response);
		e.printStackTrace();
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
