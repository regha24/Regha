package com.bnymellon.lnd.dao;

import java.sql.SQLException;
import java.util.List;

import com.bnymellon.lnd.model.BookDetails;
import com.bnymellon.lnd.model.BookIssued;
import com.bnymellon.lnd.model.UserBookDetails;

public interface BookIssuedDao {
	
	public void addDetail(BookIssued check) throws SQLException;
	
	public String getDetail(String bookId,String userId)throws SQLException;
	
	public void delete(String bookId) throws SQLException; 

	List<UserBookDetails> issuedBook()throws SQLException;
}
