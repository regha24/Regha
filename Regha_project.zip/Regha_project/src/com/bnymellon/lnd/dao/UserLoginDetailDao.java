package com.bnymellon.lnd.dao;

import java.sql.SQLException;

import com.bnymellon.lnd.model.UserLogin;

public interface UserLoginDetailDao {
	
	public UserLogin getDetail(String userName,String userPassword) throws SQLException;

}
