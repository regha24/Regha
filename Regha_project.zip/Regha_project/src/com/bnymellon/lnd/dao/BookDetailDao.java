package com.bnymellon.lnd.dao;

import java.sql.SQLException;
import java.util.List;

import com.bnymellon.lnd.model.BookDetails;

public interface BookDetailDao {
	
	public void addDetail(BookDetails check) throws SQLException;
	
	public BookDetails getDetail(String bookId)throws SQLException;
	List<BookDetails> allBook() throws SQLException;
	public void updateBookDetails(String bookId,BookDetails check) throws SQLException;
	List<BookDetails> issuedBook(String userId,String bookId ) throws SQLException;
	
}
