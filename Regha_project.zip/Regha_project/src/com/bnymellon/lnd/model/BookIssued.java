package com.bnymellon.lnd.model;

public class BookIssued {
String bookId,bookName,userName,userId;

@Override
public String toString() {
	return "BookIssued [bookId=" + bookId + ", bookName=" + bookName
			+ ", userName=" + userName + ", userId=" + userId + "]";
}

public BookIssued() {
	super();
	// TODO Auto-generated constructor stub
}

public BookIssued(String bookId, String bookName, String userName, String userId) {
	super();
	this.bookId = bookId;
	this.bookName = bookName;
	this.userName = userName;
	this.userId = userId;
}

public String getBookId() {
	return bookId;
}

public void setBookId(String bookId) {
	this.bookId = bookId;
}

public String getBookName() {
	return bookName;
}

public void setBookName(String bookName) {
	this.bookName = bookName;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public String getUserId() {
	return userId;
}

public void setUserId(String userId) {
	this.userId = userId;
}
}
