package com.bnymellon.lnd.model;

public class UserDetails {
String userId;
String userName;
String userPassword;
String userBookStatus;
@Override
public String toString() {
	return "UserDetails [userId=" + userId + ", userName=" + userName
			+ ", userPassword=" + userPassword + ", userBookStatus="
			+ userBookStatus + "]";
}
public UserDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public UserDetails(String userId, String userName, String userPassword,
		String userBookStatus) {
	super();
	this.userId = userId;
	this.userName = userName;
	this.userPassword = userPassword;
	this.userBookStatus = userBookStatus;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserPassword() {
	return userPassword;
}
public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
}
public String getUserBookStatus() {
	return userBookStatus;
}
public void setUserBookStatus(String userBookStatus) {
	this.userBookStatus = userBookStatus;
}
}
