package com.bnymellon.lnd.model;

public class UserBookDetails {

String bookId,bookName,bookAuthor,userName,userId;
int bookQuantity,bookPages,bookIsbn;
public UserBookDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public UserBookDetails(String bookId, String bookName, String bookAuthor, String userName, String userId,
		int bookQuantity, int bookPages, int bookIsbn) {
	super();
	this.bookId = bookId;
	this.bookName = bookName;
	this.bookAuthor = bookAuthor;
	this.userName = userName;
	this.userId = userId;
	this.bookQuantity = bookQuantity;
	this.bookPages = bookPages;
	this.bookIsbn = bookIsbn;
}
public String getBookId() {
	return bookId;
}
public void setBookId(String bookId) {
	this.bookId = bookId;
}
public String getBookName() {
	return bookName;
}
public void setBookName(String bookName) {
	this.bookName = bookName;
}
public String getBookAuthor() {
	return bookAuthor;
}
public void setBookAuthor(String bookAuthor) {
	this.bookAuthor = bookAuthor;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public int getBookQuantity() {
	return bookQuantity;
}
public void setBookQuantity(int bookQuantity) {
	this.bookQuantity = bookQuantity;
}
public int getBookPages() {
	return bookPages;
}
public void setBookPages(int bookPages) {
	this.bookPages = bookPages;
}
public int getBookIsbn() {
	return bookIsbn;
}
public void setBookIsbn(int bookIsbn) {
	this.bookIsbn = bookIsbn;
}
@Override
public String toString() {
	return "UserBookDetails [bookId=" + bookId + ", bookName=" + bookName + ", bookAuthor=" + bookAuthor + ", userName="
			+ userName + ", userId=" + userId + ", bookQuantity=" + bookQuantity + ", bookPages=" + bookPages
			+ ", bookIsbn=" + bookIsbn + "]";
}


}
