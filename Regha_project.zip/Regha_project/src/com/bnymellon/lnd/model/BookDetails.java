package com.bnymellon.lnd.model;

public class BookDetails {
String bookId,bookName,bookAuthor;
int bookQuantity,bookPages,bookIsbn;
public BookDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public BookDetails(String bookId, String bookName, String bookAuthor, int bookQuantity, int bookPages, int bookIsbn) {
	super();
	this.bookId = bookId;
	this.bookName = bookName;
	this.bookAuthor = bookAuthor;
	this.bookQuantity = bookQuantity;
	this.bookPages = bookPages;
	this.bookIsbn = bookIsbn;
}
public String getBookId() {
	return bookId;
}
public void setBookId(String bookId) {
	this.bookId = bookId;
}
public String getBookName() {
	return bookName;
}
public void setBookName(String bookName) {
	this.bookName = bookName;
}
public String getBookAuthor() {
	return bookAuthor;
}
public void setBookAuthor(String bookAuthor) {
	this.bookAuthor = bookAuthor;
}
public int getBookQuantity() {
	return bookQuantity;
}
public void setBookQuantity(int string) {
	this.bookQuantity = string;
}
public int getBookPages() {
	return bookPages;
}
public void setBookPages(int bookPages) {
	this.bookPages = bookPages;
}
public int getBookIsbn() {
	return bookIsbn;
}
public void setBookIsbn(int bookIsbn) {
	this.bookIsbn = bookIsbn;
}

}
