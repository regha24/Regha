package com.bnymellon.lnd.model;

public class UserLogin {
String userId,userPassword,userRole,userName;

public UserLogin(String userId, String userPassword, String userRole, String userName) {
	super();
	this.userId = userId;
	this.userPassword = userPassword;
	this.userRole = userRole;
	this.userName = userName;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public String getUserId() {
	return userId;
}

public void setUserId(String userId) {
	this.userId = userId;
}

public String getUserPassword() {
	return userPassword;
}

public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
}

public String getUserRole() {
	return userRole;
}

public void setUserRole(String userRole) {
	this.userRole = userRole;
}


public UserLogin() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "UserLogin [userId=" + userId + ", userPassword=" + userPassword
			+ ", userRole=" + userRole + "]";
}

}
